Data Visualization with D3 Template
===================================

This is ready to go development environment for a standard d3 powered visualization project.

